# TD - Trial design

TD is a command line tool to create beautiful Schedule-of-Assessments figures for clinical study designs.

The input describing the study design is expected as a json-formatted text file.

The output is provided in vector graphic form (as a .svg file) that can be easily included in Office documents or websites.
